/*interface Arithmetic{

    double calc(double num1, double num2);
}




public class Main {
    static void calculate(double num1, double num2, Arithmetic op) {
        double result = op.calc(num1, num2);
        System.out.println("Result: " + result);
    }

 */
interface Check<T>
{
    boolean compare(T x,T y);
}
public class Main {
    static <T> int countIf(T[] arr, T key, Check<T> c) {

        int count = 0;
        for (T x : arr)
            if (c.compare(x, key))
                count++;
        return count;


    }

    public static void main(String[] args) {
        Integer[] arr = {44, 77, 99, 22, 55, 66};
        Integer key = 50;
        int cnt = countIf(arr, key, (x, y) -> x > y);
        System.out.println("Count = " + cnt);

    }

}