import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//Calculate the factorial of the given number using stream operations by lambada function .
public class Main {
    public static void main(String[] args) {
        Stream<Integer> s1=Stream.iterate(1,n->n+1)
                .limit(5);
//        List<Integer> l1=s1
//                .collect(Collectors.toList());
//        System.out.println(l1);
//        int fact=1;
//        for(Integer i:l1)
//            fact=fact*i;
//        System.out.println(fact);
//
        Integer res = s1.reduce(1, (a, n) -> a * n);
        System.out.println("Result: " + res);
    }

    }

