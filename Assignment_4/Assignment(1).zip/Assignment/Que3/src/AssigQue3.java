
public class AssigQue3 {
    public static void main(String[] args) {
    String s1[]=new String[]{"a","b","c","d"};
    String s2[]=new String[]{"a","f","c","e"};
//    System.out.println("Check is Equal="+s1.equals(s2));
    for (int i=0;i< s1.length;i++)
    {
        for(int j=0;j<s2.length;j++)
        {
            if(s1[i]==s2[j]){
                System.out.println(s1[i]);
            }
        }

    }





    }
}
