package p1;

import java.util.Scanner;

public class Hourly_Employee extends Employee{
    int hours;
    double wage=100.23;
    public Hourly_Employee(String firstname, String lastName, int SSN,int hours) {
        super(firstname, lastName, SSN);
        this.hours=hours;
    }

    public Hourly_Employee() {
        super();
    }

    @Override
    void a1() {

        Scanner sc=new Scanner(System.in);

        System.out.println("Enter no. of hrs employee work=");
        hours=sc.nextInt();
         if (hours<=40){
             System.out.println("earning="+(wage*hours));
             super.display();
             System.out.println("hourley wage:"+wage);
             System.out.println("hourley work:"+hours);
         }
         else if (hours>40) {

             System.out.println("earning="+(40*wage+(hours-40)*wage*1.5));
             super.display();
             System.out.println("hourley wage:"+wage);
             System.out.println("hourley work:"+hours);
         }


    }
}
