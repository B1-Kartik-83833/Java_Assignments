package p1;

import java.util.Scanner;

public class Commission_Employee extends Employee{

    public Commission_Employee(String firstname, String lastName, int SSN) {
        super(firstname, lastName, SSN);

    }

    public Commission_Employee() {
        super();
    }

    @Override
    void a1() {

//        super.acceptdata();
        double earning=commisionrate*grossSales;
        super.display();
        System.out.println("earning of commision:"+earning);
        System.out.println("gross sales:"+grossSales);
        System.out.println("commision rate:"+commisionrate);
    }
}
