import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        TreeSet<String> s1=new TreeSet<String>();
        s1.add("Blue");
        s1.add("Purple");
        s1.add("Red");
        s1.add("Green");
        System.out.println(s1);

    }
}