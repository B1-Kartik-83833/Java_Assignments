import java.util.Scanner;

public class CreditLimitCalculator
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter account number : ");
        int accountNumber = sc.nextInt();

        System.out.println("Enter balance at the beginning of the month : ");
        int beginningBalance = sc.nextInt();

        System.out.println("Enter total of all items charged this month : ");
        int totalCharges = sc.nextInt();

        System.out.print("Enter total of all credits applied this month: ");
        int totalCredits = sc.nextInt();

        System.out.print("Enter allowed credit limit: ");
        int creditLimit = sc.nextInt();

        int newBalance = beginningBalance + totalCharges - totalCredits;
        System.out.println("New balance = "+newBalance);
        if (newBalance > creditLimit)
            System.out.println("Credit limit exceeded.");
    }
}
