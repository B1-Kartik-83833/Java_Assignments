import java.util.Scanner;

/*Create a functional interface Arithmetic with single abstract method double calc(double,double). Write a static method calculate() in main
class as follows. In main(), write a menu driven program that inputs two numbers from the user and calls calculate() method with appropriate lambda
expression (in arg3) to perform addition, subtraction, multiplication and division operations.
*/
interface Arithmetic{

    double calc(double num1, double num2);
}




public class Main {
    static void calculate(double num1, double num2, Arithmetic op) {
        double result = op.calc(num1, num2);
        System.out.println("Result: " + result);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter num1=");
        double x = sc.nextDouble();
        System.out.println("Enter num2=");
        double y = sc.nextDouble();
        System.out.println("Addition");
        System.out.println("Subtraction");
        System.out.println("Multiplication");
        System.out.println("Division");
        System.out.println("Exit");

        while (true) {
            System.out.println("Enter choice=");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    calculate(x, y, (num1, num2) -> num1 + num2);
                    break;
                case 2:
                    calculate(x, y, (num1, num2) -> num1 - num2);
                    break;
                case 3:
                    calculate(x, y, (num1, num2) -> num1 * num2);
                    break;
                case 4:
                    calculate(x, y, (num1, num2) -> num1 / num2);
                    break;

                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");


            }
        }

    }
}
