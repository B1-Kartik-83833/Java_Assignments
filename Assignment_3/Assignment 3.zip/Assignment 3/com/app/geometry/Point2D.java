package com.app.geometry;
import java.lang.Math;
import java.util.Objects;
public class Point2D
{
    double x;
    double y;

    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public String getDetails()
    {
        return "Point: (" + x + ", " + y + ")";
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Point2D other = (Point2D) obj;
        return x == other.x && y == other.y;
    }

    public double calculateDistance(Point2D obj)
    {
        return Math.sqrt((Math.pow((obj.x - this.x),2) + Math.pow((obj.y - this.y),2)));
    }
}
