import java.util.stream.IntStream;
import java.util.stream.Stream;

//Create a collatz conjure series for the given number. Tn+1 = Tn / 2 (if Tn is even), and Tn+1 = 3 * Tn + 1 (if Tn is odd).
public class Main {
    public static void main(String[] args) {
        int num=5;
        Stream.iterate(num,n->n/2==0?n/2:3*n+1)
                .peek(n-> System.out.println(n))
                .allMatch(n ->  n >1);


    }
}