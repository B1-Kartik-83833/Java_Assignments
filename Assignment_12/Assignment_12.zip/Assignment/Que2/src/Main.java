//Write a program to calculate sum of 10 unique even random integers using streams.

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Random r1 = new Random();
        Stream<Integer> s1 = Stream.generate(() -> r1.nextInt(100))
                .limit(10);


        List<Integer> l1 = s1
                .map(x -> x + 1)
                .collect(Collectors.toList());

        System.out.println(l1);
        int sum=0;
        for(Integer x : l1)
            System.out.println(sum=sum+x);
        System.out.println("sum="+sum);

    }
}