//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
//Write a program to count occurrences of each word from a ﬁle.
//Hint 1: To read all lines from the ﬁle use Stream<String> stream = Files.lines(path);
//Hint 2: Use mergeFunction in Collectors.toMap()


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) throws IOException {
        Stream<String> stream = Files.lines(Paths.get("/home/prajwal/Java/Day17/Assignment/Que4/src"));
        Stream.of(stream)
                .flatMap(s ->Stream.of(s.split("")))

    }
}