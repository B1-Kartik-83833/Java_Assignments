package p1;

import java.util.Scanner;

public class BasePlus_Commission_Employee extends Employee {

    public BasePlus_Commission_Employee(String firstname, String lastName, int SSN) {
        super(firstname, lastName, SSN);

    }

    public BasePlus_Commission_Employee() {
        super();
    }

    @Override
    void a1() {
//        super.acceptdata();
        double earning=(commisionrate*grossSales)+baseSalary;

        super.display();
        System.out.println("earning of Base_plus:"+earning);
        System.out.println("commision rate:"+commisionrate);
        System.out.println("base salary:"+baseSalary);
    }

}
