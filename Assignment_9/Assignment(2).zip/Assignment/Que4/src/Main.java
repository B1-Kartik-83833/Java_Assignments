import java.awt.*;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Main {
    private int Main;

    public static void main(String[] args) {
        List<Integer> l1= new  ArrayList<Integer>();
        l1.add(2);
        l1.add(3);
        l1.add(4);
        System.out.println(l1);


        System.out.println("-----------");

        List<Double> l2= new  ArrayList<Double>();
        l2.add(2.3);
        l2.add(3.6);
        l2.add(4.6);
        System.out.println(l2);
        System.out.println(findMaxNumber(l1));
        System.out.println(findMaxNumber(l2));

    }


        public static <T extends Comparable<T>> T findMaxNumber(List<T> list) {
            if (list == null || list.isEmpty()) {
                throw new IllegalArgumentException("List is either null or empty.");
            }

            T max = list.get(0);
            for (T element : list) {
                if (element.compareTo(max) > 0) {
                    max = element;
                }
            }

            return max;
        }

    }



