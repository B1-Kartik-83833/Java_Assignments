package p1;

public class Salaried_Employee extends Employee{
    int weekSalary;
   public Salaried_Employee(){
       super();

   }
    public Salaried_Employee(int weekSalary,String firstname, String lastName, int SSN) {
        super(firstname,lastName,SSN);
        this.weekSalary = weekSalary;
    }

    @Override
    void a1() {
        double Salary=weekSalary+(0.1 * baseSalary);
        super.display();
        System.out.println("weekly salary:"+Salary);

    }
}
