import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;

enum Category{
    Fiction, Non_Fiction, Science_Fiction, Drama;
    String name;
//    Category(String name) {
//        this.name = name;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }

//    public boolean valueOf() {
//        Fiction.valueOf();
//        return false;
//    }
}

class Date{
public int dd;
public int mm;
public int yy;
public Date(){

}
    public Date(int dd, int mm, int yy) {
        this.dd = dd;
        this.mm = mm;
        this.yy = yy;
    }

    public int getDd() {
        return dd;
    }

    public void setDd(int dd) {
        this.dd = dd;
    }

    public int getMm() {
        return mm;
    }

    public void setMm(int mm) {
        this.mm = mm;
    }

    public int getYy() {
        return yy;
    }

    public void setYy(int yy) {
        this.yy = yy;
    }

    void display_date(){
        System.out.println(this.dd +"/" +this.mm +"/"+this.yy);
    }

    @Override
    public String toString() {
        return "Date{" +
                "dd=" + dd +
                ", mm=" + mm +
                ", yy=" + yy +
                '}';
    }
}





class Book {
    private String isbn;
    Category cl;
    double price;
    public Date dob;
    String author_name;
    int quantity;

    public Book(String isbn, double price, Date dob, String author_name, int quantity, Category cl) {
        this.isbn = isbn;
        this.price = price;
        this.dob = dob;
        this.author_name = author_name;
        this.quantity = quantity;

        this.cl= cl;

    }

    void dispaly(){
        System.out.println(isbn);
        System.out.println(price);
        System.out.println(dob);
        System.out.println(author_name);
        System.out.println(quantity);
        dob.display_date();
        System.out.println(cl.getClass());

    }

    @Override
    public String toString() {
        return "Book{" +
                "isbn='" + isbn + '\'' +
                ", cl=" + cl +
                ", price=" + price +
                ", dob=" + dob +
                ", author_name='" + author_name + '\'' +
                ", quantity=" + quantity +
                '}';
    }

    public Comparable<Date> dob() {

        return (Comparable<Date>) new Date(dob.dd,dob.mm,dob.yy);
    }
}
class Date_compare implements Comparator<Book>{


    @Override
    public int compare(Book t1, Book t2) {
        return t1.dob().compareTo(t2.dob);
    }

}



public class Main {
    public static void main(String[] args) {
        Book b1=new Book("1",100.00,new Date(1,1,2000),"Author1",10,Category.Fiction);
        Book b2=new Book("2",200.00,new Date(2,1,2000),"Author2",20,Category.Drama);
        Book b3=new Book("3",300.00,new Date(3,1,2000),"Author3",30,Category.Non_Fiction);
        Book b4=new Book("4",400.00,new Date(4,1,2000),"Author4",40,Category.Science_Fiction);
        Book b5=new Book("5",300.00,new Date(5,1,2000),"Author5",50,Category.Drama);

        HashSet<Book> hs1=new HashSet<Book>();
//        for(int i =0;i<3;i++)
//        {
//            Book b = new Book();
//            b.accpt();
//            hs1.add(b)
//
//        }
        hs1.add(b1);
        hs1.add(b2);
        hs1.add(b3);
        hs1.add(b4);
        hs1.add(b5);
        System.out.println(hs1);
        System.out.println("-*-*-**-*--**-**-*-**-*-*-*");
//// Converting from hashset to linkedhashset
        LinkedHashSet<Book> lb1= new LinkedHashSet<Book>(hs1);

        System.out.println(lb1);
        System.out.println("-------date compare--------");

        Date_compare dc1= new Date_compare();
        System.out.println(Collections.sort(hs1,dc1));
//        Collections.sort(hs1,dc1);
        for(Book e: lb1)
            System.out.println(e);









    }
}