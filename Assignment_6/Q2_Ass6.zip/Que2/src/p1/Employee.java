package p1;

import java.util.Scanner;

public abstract class Employee {

    String firstname;
    String lastName;
    int SSN;
    double commisionrate=900;
    double grossSales=600;
    double baseSalary=500.0;

    public Employee(String firstname, String lastName, int SSN)
    {
        this.firstname = firstname;
        this.lastName = lastName;
        this.SSN = SSN;
    }

    public Employee() {

    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getSSN() {
        return SSN;
    }

    public void setSSN(int SSN) {
        this.SSN = SSN;
    }

    abstract void a1();
    void display(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first name:");
        firstname=sc.next();
        System.out.println("Enter last name:");
        lastName=sc.next();
        System.out.println("Enter social security no");
        SSN=sc.nextInt();
        System.out.println("salaried employee:"+firstname+"\t"+lastName);
        System.out.println("social security number:"+SSN);
    }
//    void acceptdata(){
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter commissioion rate:");
//        double commisionrate=sc.nextDouble();
//        System.out.println("Enter grossSales:");
//        double grossSales=sc.nextDouble();
////        double earning=commisionrate*grossSales;
////        System.out.println("enter base salary");
////        baseSalary= sc.nextDouble();
//
//    }


}

