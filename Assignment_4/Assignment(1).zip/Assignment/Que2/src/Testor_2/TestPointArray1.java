package Testor_2;
import com.app.geometry.Point2D;
import java.lang.Math;

import java.util.Arrays;
import java.util.Scanner;


public class TestPointArray1 {
    Scanner sc2 = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner sc2 = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        System.out.println("enter no. of points to make");
        Point2D[] points = new Point2D[sc.nextInt()];

        for (int i = 0; i < points.length; i++) {
            System.out.println("enter x and y");

            points[i] = new Point2D(sc2.nextInt(), sc2.nextInt());
        }
        System.out.println("-----------------------------");

        System.out.println("1. Display details of a specific point");
        System.out.println("2) Display x, y co-ordinates of all points");
        System.out.println("3) User i/p : 2 indices for the points , validate the indices");
        System.out.println("4. Exit");
        System.out.println("Enter choice");
        Scanner sc3 = new Scanner(System.in);
        int choice;
        choice = sc3.nextInt();
        switch (choice) {
            case 1:
                Scanner sc4 = new Scanner(System.in);
                System.out.println("point which to display");
//                System.out.println(points[sc4.nextInt()]);
                int a;
                a=sc4.nextInt();
                if (a < points.length) {
                    System.out.println(points[a]);
                }
                else {
                    System.out.println("Error point is not present");
                }
                break;


            case 2:
                for (int j = 0; j < points.length; j++) {
                    System.out.println("point" + j);
                    points[j].getDetails();

                }
                break;
            case 3:
                System.out.println("distance of point P1");
                Scanner sc5 = new Scanner(System.in);
                System.out.println("To distance of point P2");
                Scanner sc6 = new Scanner(System.in);
                int b=sc5.nextInt();
                int c=sc6.nextInt();

                if (points[b].equals(points[c])) {
                    System.out.println("points Are Same and distance is zero");
                }
                else {
                    System.out.println(points[b]);
                    Point2D p1=points[b];

                    System.out.println(points[c]);
                    Point2D p2=points[c];
                    System.out.println("Distance between points"+p1.Calculate_distance(p2));
                }

                break;

            case 4:
                System.out.println("exit");
                break;
            default:
                System.out.println("Wrong Choice");
        }
    }
}






