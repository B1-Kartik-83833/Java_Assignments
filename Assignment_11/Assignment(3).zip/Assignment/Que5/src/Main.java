import java.util.Objects;
import java.util.Scanner;

/*In above assignment, create one more array of Double (constant values) where few elements are repeated. Input a key from user and check how many
times key is repeated in the array using appropriate lambda expression.
*/
interface Check<T>
{
    boolean compare(T x,T y);

//    boolean equals(T x, T key);
}
public class Main {


    static <T> int countIf(T[] arr, T key, Check<T> c){
        int count = 0;
        for(T x:arr)
//            if(c.equals(x,key))
            if (c.compare(x,key))
                count++;
        return  count;

    }

    public static void main(String[] args) {
        Double [] arr = {44.4, 77.0, 99.3, 22.2, 44.4,44.4,55.3, 66.5};
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter a key");
        Double key = sc.nextDouble();
        double cnt = countIf(arr, key, (x,y)-> Objects.equals(y, x));
        System.out.println("Count = " + cnt);
    }

}