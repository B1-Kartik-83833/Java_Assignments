abstract class Employee {
    private final String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getname() {
        return name;
    }

    public abstract double calculatePay();
}

class salariedEmployee extends Employee{
    private final double weeklysalary;
    public salariedEmployee(String name, double weeklysalary){
        super(name);
        this.weeklysalary = weeklysalary;
    }
    @Override
    public double calculatePay(){
        return weeklysalary;
    }
}

class HourlyEmployee extends Employee{
    private final double wage;
    private final int hoursWorked;

    public HourlyEmployee(String name, double wage, int hoursWorked){
        super(name);
        this.wage = wage;
        this.hoursWorked = hoursWorked;
    }
    @Override
    public double calculatePay(){
        double pay = hoursWorked * wage;
        if (hoursWorked > 40)
            pay += (hoursWorked - 40) * wage * 1.5;
        return pay;
    }
}

class CommissionEmployee extends Employee {
    private final double sales;
    private final double commissionRate;

    public CommissionEmployee(String name, double sales, double commissionRate) {
        super(name);
        this.sales = sales;
        this.commissionRate = commissionRate;
    }

    @Override
    public double calculatePay() {
        return sales * commissionRate;
    }
}

class BaseSalariedCommissionEmployee extends CommissionEmployee {
    private final double baseSalary;

    public BaseSalariedCommissionEmployee(String name, double sales, double commissionRate, double baseSalary) {
        super(name, sales, commissionRate);
        this.baseSalary = baseSalary;
    }

    @Override
    public double calculatePay() {
        double adjustedBaseSalary = baseSalary * 1.1;
        return super.calculatePay() + adjustedBaseSalary;
    }
}
public class PayrollSystem
{
    public static void main(String[] args) {
        Employee[] employees = new Employee[4];
        employees[0] = new salariedEmployee("Hemant", 10000);
        employees[1] = new HourlyEmployee("Puneet", 150, 45);
        employees[2] = new CommissionEmployee("Aryaa", 50000, 0.15);
        employees[3] = new BaseSalariedCommissionEmployee("Kamlesh", 10000, 0.5, 2000);

        for (Employee emp:employees){
            System.out.println("Employee " + emp.getname() + ", Weekly Pay: Rs" + emp.calculatePay());
        }
    }
}
