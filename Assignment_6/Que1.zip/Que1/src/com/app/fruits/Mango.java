package com.app.fruits;

public class Mango extends Fruit{

    public Mango(String colour, double weight, String name, boolean isFresh) {
        super(colour, weight, name, isFresh);
    }
    public String toString(){
        return super.toString();
    }
    public String taste(){
        return "sweet";
    }
}
