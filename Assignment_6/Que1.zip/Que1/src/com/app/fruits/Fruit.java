package com.app.fruits;

public class Fruit {
    String colour;
    double weight;
    String name;
    boolean isFresh;

    public Fruit(String colour, double weight, String name,boolean isFresh) {
        this.colour = colour;
        this.weight = weight;
        this.name = name;
        this.isFresh=isFresh;
    }
    public String toString(){
        return "name="+this.name+"\t"+"color="+this.colour+"\t"+"weight="+this.weight ;
    }
    public String taste(){
        return "no specific taste";
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isFresh() {
        return isFresh;
    }

    public void setFresh(boolean fresh) {
        isFresh = fresh;
    }
}
