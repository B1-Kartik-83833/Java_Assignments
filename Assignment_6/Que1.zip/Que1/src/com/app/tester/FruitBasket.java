package com.app.tester;

import com.app.fruits.*;

import java.util.Scanner;

public class FruitBasket {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter bag size");
        int n= sc.nextInt();
        Fruit fb1[] =new Fruit[n];
        System.out.println("1. Add Mango");
        System.out.println("2. Add Orange");
        System.out.println("3. Add Apple");
        System.out.println("4. Display names of all fruits in the basket.");
        System.out.println("5. Display name,color,weight , taste of all fresh fruits , in the basket.");
        System.out.println("6. Display tastes of all stale(not fresh) fruits in the basket");
        System.out.println("7. Mark a fruit as stale");
        System.out.println("8. Exit");
        int count=0;
        while (true){
            Scanner sc2=new Scanner(System.in);
            System.out.println("enter choice");
            int choice= sc2.nextInt();

            switch (choice){
                case 1:

                    fb1[count++]=new Mango("yellow",2.3,"mango",true);
//                    System.out.println(fb1.toString());
                    break;


                case 2:
                    fb1[count++]=new Orange("orange",2.5,"orange",true);
//                    System.out.println(fb1.toString());
                    break;

                case 3:
                    fb1[count++]=new Apple("Red",2.5,"Apple",false);
//                    System.out.println(fb1.toString());
                    break;


                case 4:
                    for(int i=0;i<fb1.length;i++)
                    {
                        System.out.println(fb1[i].getName());
                    }

                    break;


                case 5:
                    for(int i=0;i<fb1.length;i++)
                    {
                        System.out.println(fb1[i]);
                        System.out.println("isFresh="+(fb1[i].isFresh()));
                    }
                    break;


                case 6:
                    for (int i=0;i<fb1.length;i++)
                        if(fb1[i].isFresh()==false){
                            System.out.println(fb1[i].getName());
                        }
//                        else {
//                            System.out.println("all fruits are fresh");
//                        }
                    break;


                case 7:
                    Scanner sc3=new Scanner(System.in);
                    System.out.println("which fruit element  to make");
                    int m=sc3.nextInt();
                    if(m>fb1.length)
                    {
//                        for (int i=0;i<fb1.length;i++)
//                        fb1[i]
                        System.out.println("error");
                    }
                    else {
                        fb1[m].setFresh(false);
                        System.out.println(fb1[m]);
                        System.out.println(fb1[m].isFresh());
                    }
                    break;


                case 8:
                    System.out.println("exit");
                    break;
                default:
                    break;

            }


        }


    }



}