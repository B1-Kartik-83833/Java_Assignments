package com.app.fruits;

public class Fruit
{
    String name;
    String color;
    double weight;
    boolean isFresh;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public boolean isFresh() {
        return isFresh;
    }

    public void setFresh(boolean fresh) {
        isFresh = fresh;
    }

    Fruit(String name, String color, double weight)
    {
        this.name = name;
        this.color = color;
        this.weight = weight;
        this.isFresh = true;
    }

    Fruit(){
        this.name = "Mango";
        this.color = "Yellow";
        this.weight = 50.84;
        this.isFresh = true;
    }

    @Override
    public String toString(){
        return "Name = " + name + "Color = " + color + "Weight = " + weight;
    }

    public String taste(){
        return " no specific taste ";
    }
}

class Apple extends Fruit
{
    Apple(String color, double weight){
        super("Apple", color, weight);
    }
    @Override
    public String taste(){
        return " sweet n sour ";
    }
}

class Orange extends Fruit
{
    Orange(String color, double weight){
        super("Orange", color, weight);
    }

    @Override
    public String taste(){
        return " sour ";
    }
}

class Mango extends Fruit
{
    Mango(String color, double weight){
        super("Mango", color, weight);
    }

    @Override
    public String taste(){
        return " sweet ";
    }
}