package com.app.fruits;

import java.util.Scanner;

public class FruitBasket
{
    static final int MAX_FRUITS = 10;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Fruit[] basket = new Fruit[MAX_FRUITS];
        int counter = 0;

        while (true)
        {
            System.out.println("Options : ");
            System.out.println("1. Add Mango ");
            System.out.println("2. Add Orange ");
            System.out.println("3. Add Apple ");
            System.out.println("4. Display names of all fruits in the basket ");
            System.out.println("5. Display name, color, weight, taste of all fresh fruits in the basket ");
            System.out.println("6. Display tastes of all stale(not fresh) fruits in the basket ");
            System.out.println("7. Mark a fruit as stale ");
            System.out.println("8. Exit ");
            System.out.println("*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
            System.out.println("Enter your choice : ");
            int choice = sc.nextInt();

            switch (choice)
            {
                case 1:
                    if (counter < MAX_FRUITS){
                        System.out.println("Enter color of Mango : ");
                        String mangoColor = sc.next();
                        System.out.println("Enter weight of Mango : ");
                        double mangoWeight = sc.nextDouble();
                        basket[counter++] = new Mango(mangoColor, mangoWeight);
                        System.out.println("Mango added to the basket.");
                    }else {
                        System.out.println("Basket is Full ! ");
                    }
                    break;

                case 2:
                    if (counter < MAX_FRUITS){
                        System.out.println("Enter color of Orange : ");
                        String orangeColor = sc.next();
                        System.out.println("Enter weight of Orange : ");
                        double orangeWeight = sc.nextDouble();
                        basket[counter++] = new Orange(orangeColor, orangeWeight);
                        System.out.println("Orange added to the basket. ");
                    }else {
                        System.out.println("Basket is Full ! ");
                    }
                    break;

                case 3:
                    if (counter < MAX_FRUITS){
                        System.out.println("Enter color of Apple : ");
                        String appleColor = sc.next();
                        System.out.println("Enter weight of Apple : ");
                        double appleWeight = sc.nextDouble();
                        basket[counter++] = new Apple(appleColor, appleWeight);
                        System.out.println("Apple added to the basket. ");
                    }else {
                        System.out.println("Basket is Full ! ");
                    }
                    break;

                case 4:
                    System.out.println("Names of Fruits in the basket : ");
                    for (Fruit fruit : basket){
                        if (fruit != null)
                            System.out.println(fruit.getName());
                    }
                    break;

                case 5:
                    System.out.println("Name, Color, Weight, Taste of all fresh fruits in the basket : ");
                    for (Fruit fruit : basket){
                        if (fruit != null && fruit.isFresh())
                            System.out.println("Name = "+fruit.getName()+" Color = "+fruit.getColor()+" Weight = "+fruit.getWeight()+" Taste = "+fruit.taste());
                    }
                    break;

                case 6:
                    System.out.println("Tastes of all stale(not fresh) fruits in the basket ");
                    for (Fruit fruit : basket){
                        if (fruit != null && !fruit.isFresh())
                            System.out.println("Taste = "+fruit.taste());
                    }
                    break;

                case 7:
                    System.out.println("Enter index of fruit to mark as stable : ");
                    int index = sc.nextInt();
                    if (index >= 0 && index < counter){
                        if (basket[index] != null){
                            basket[index].setFresh(false);
                            System.out.println("Fruit marked as stable ");
                        }else {
                            System.out.println("No fruit at this index ");
                        }
                    }else {
                        System.out.println("Invalid index!");
                    }
                    break;

                case 8:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}