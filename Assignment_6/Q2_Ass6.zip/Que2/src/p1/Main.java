package p1;

public class Main {
    public static void main(String[] args) {
        Salaried_Employee s1=new Salaried_Employee();
        s1.a1();

        System.out.println("-------------------------");
        Hourly_Employee h1=new Hourly_Employee();
        h1.a1();

        System.out.println("------------------------");
        Commission_Employee c1=new Commission_Employee();
        c1.a1();

        System.out.println("----------------------");
        BasePlus_Commission_Employee b1=new BasePlus_Commission_Employee();
        b1.a1();

    }
}
