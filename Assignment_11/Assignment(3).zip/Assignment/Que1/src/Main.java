import java.util.Scanner;

/*
//public class Main {Create an interface Emp with abstract method double getSal() and a default method default double calcIncentives(). The default method
//    simply returns 0.0. Create a class Manager (with ﬁelds basicSalary and dearanceAllowance) inherited from Emp. In this class override getSal() method
//            (basicSalary + dearanceAllowance) as well as calcIncentives() method (20% of basicSalary). Create another class Labor (with ﬁelds hours and rate)
//inherited from Emp interface. In this class override getSal() method (hours * rate) as well as calcIncentives() method (5% of salary if hours > 300,
//                                                                                                                        otherwise no incentives). Create another class Clerk (with ﬁeld salary) inherited from Emp interface. In this class override getSal() method (salary). Do
//    not override, calcIncentives() in Clerk class. In Emp interface create a static method static double calcTotalIncome(Emp arr[]) that calculate
//    total income (salary + incentives) of all employees in the given array.
//}
*/
interface Emp{
    double getSal();
    default double calcIncentives(){
        return 0.0;
    }
    static double calcTotalIncome(Emp arr[]){
        double total=0.0;
        for (Emp e:arr)
            total += e.getSal();
        return total;

    }
}
class Manager implements Emp {
    double basicSalary;
    double dearanceAllowance;

    public Manager(double basicSalary, double dearanceAllowance) {
        this.basicSalary = basicSalary;
        this.dearanceAllowance = dearanceAllowance;

    }


    @Override
    public double getSal() {
        return basicSalary + dearanceAllowance;
    }

    @Override
    public double calcIncentives() {
        return 0.2 * basicSalary;
    }
}
class Labor implements Emp {
    int hours;
    double rate;

    public Labor(int hours, double rate) {
        this.hours = hours;
        this.rate = rate;
    }

    @Override
    public double getSal() {
        return hours*rate;
    }

    @Override
    public double calcIncentives() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter hours");
        hours=sc.nextInt();
        if(hours>300){
            return 0.05*hours;
        }
        else{
            return 0.0;
        }

    }
}
class Clerk implements Emp {
    double salary;

    public Clerk(double salary) {
        this.salary = salary;
    }

    @Override
    public double getSal() {
        return salary;
    }
    @Override
    public double calcIncentives() {
        return 0.0;
    }

}
public class Main {
    public static void main(String[] args) {
        Emp [] arr = new Emp[]{
                new Manager(500.0, 13.6),
                new Labor(400, 10.0),
                new Clerk(1000.0)
        };
    double total=Emp.calcTotalIncome(arr);
        System.out.println("total inceventatives");
        System.out.println(total);




    }
    }


