package com.app.geometry;

import java.util.Objects;

public class Point2D {
    public int x;
    public int y;

    public Point2D() {


    }

    public Point2D(int x, int y) {
        this.x = x;
        this.y = y;

    }



    public void getDetails() {
        System.out.println("x=" + x);
        System.out.println("y=" + y);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Point2D)) return false;
        Point2D point2D = (Point2D) o;
        return x == point2D.x && y == point2D.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
    public String toString(){
        return "X="+this.x +"Y="+this.y;
    }
    public double Calculate_distance(Point2D other){
        return Math.sqrt(Math.pow((other.x - this.x), 2) + Math.pow((other.y - this.y), 2));
    }

}

